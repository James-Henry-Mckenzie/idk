from re import A
from PySide6.QtWidgets import *
import os



app = QApplication()
main_window = QMainWindow()
main_window.setWindowTitle("Quiz")


main_widget = QWidget()
main_window.setCentralWidget(main_widget)
# main_window.resize(600, 400)
main_window.setGeometry(480, 270, 960, 540)

vbox = QVBoxLayout()
main_widget.setLayout(vbox)

info = QLabel("Click button and shiz")
button = QPushButton("Code Editor")
vbox.addWidget(info)
vbox.addWidget(button)


editor = QWidget()
editor.setGeometry(480, 270, 960, 540)
editor.label = QLabel("Code Editor")
vert = QVBoxLayout()
editor.setLayout(vert)

text_inp = QTextEdit()
# text_inp.setTabStopDistance("   ")
clse = QPushButton("Close")

vert.addWidget(text_inp)
vert.addWidget(clse)


def editor_show():
    editor.show()
    main_window.hide()

def editor_hide():
    print(text_inp.toPlainText())
    main_window.show()
    editor.hide()

button.clicked.connect(editor_show)
clse.clicked.connect(editor_hide)

# main_window.setStyleSheet("border: 1px solid black")
editor.show()
main_window.show()
editor.hide()
app.exec()

# poop = 10
# a = f"{poop} hllo"
# print(a)



def save():
    ## Code attributed to:
    # Szabolcs 
    # - https://stackoverflow.com/questions/42486764/python-creating-a-new-file-folder-in-the-same-directory-as-the-script

    d = os.path.dirname(__file__)
    p = f"{d}/test"

    try:
        os.makedirs(p)
    except:
        print("didn't work")